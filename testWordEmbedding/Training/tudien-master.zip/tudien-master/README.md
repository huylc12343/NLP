# Từ điển tiếng Việt - Vietnamese Dictionary

A collection of Vietnamese data files in text format for language processing, security and general research

Tuyển tập các từ tiếng Việt dạng txt dùng để xử lý ngôn ngữ, bảo mật, hoặc nghiên cứu chung

Nguồn:
* https://github.com/phuong/spacy.vi
* https://github.com/kikout13/AnalyzerText